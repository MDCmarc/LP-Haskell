-- a) iterate o scanl o recursivo

